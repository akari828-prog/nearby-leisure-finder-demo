import 'package:flutter_test/flutter_test.dart';
import 'package:nearby_leisure_finder/models/rss_event.dart';
import 'package:nearby_leisure_finder/services/local_event_classifier.dart';

void main() {
  group('LocalEventClassifier', () {
    const classifier = LocalEventClassifier();

    test('includes a local family leisure event and extracts stated details', () {
      final result = classifier.classify(const <RssEvent>[
        RssEvent(
          title: '秋のマルシェを開催',
          description:
              '概要：地元の野菜や雑貨が並ぶ催しです。開催日時：2026年10月10日 10:00〜16:00。会場：東京都千代田区丸の内1丁目。',
          url: 'https://example.com/marche',
          sourceName: '出典',
        ),
      ]);

      expect(result, hasLength(1));
      expect(result.single.index, 0);
      expect(result.single.isLeisure, isTrue);
      expect(result.single.summary, contains('地元の野菜'));
      expect(result.single.address, contains('東京都千代田区'));
      expect(result.single.startTime, DateTime(2026, 10, 10, 10));
      expect(result.single.endTime, DateTime(2026, 10, 10, 16));
    });

    test('rejects business and online-only activities', () {
      final result = classifier.classify(const <RssEvent>[
        RssEvent(
          title: 'IT勉強会のお知らせ',
          description: '地域イベントの会場で開催します。',
          url: 'https://example.com/study',
          sourceName: '出典',
        ),
        RssEvent(
          title: 'オンラインイベント開催',
          description: '家族向けの企画をライブ配信します。',
          url: 'https://example.com/online',
          sourceName: '出典',
        ),
      ]);

      expect(result.map((item) => item.isLeisure), everyElement(isFalse));
    });

    test('does not invent address or dates when details are absent', () {
      final result = classifier.classify(const <RssEvent>[
        RssEvent(
          title: '街のグルメフェス',
          description: '地元のお店が集まるイベントです。',
          url: 'https://example.com/food',
          sourceName: '出典',
        ),
      ]);

      expect(result.single.isLeisure, isTrue);
      expect(result.single.address, isNull);
      expect(result.single.startTime, isNull);
      expect(result.single.endTime, isNull);
    });
  });
}
