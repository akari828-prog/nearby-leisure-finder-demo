#!/usr/bin/env python3
"""Convert a registered Android Firebase app's JSON to Flutter build defines."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile


DEFAULT_PACKAGE_NAME = "jp.example.nearbyleisurefinder"


def required_text(value, field_name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"Firebase設定の {field_name} がありません。")
    return value.strip()


def build_defines(document, package_name):
    if not isinstance(document, dict):
        raise ValueError("Firebase設定はJSONオブジェクトである必要があります。")
    project = document.get("project_info")
    if not isinstance(project, dict):
        raise ValueError("Firebase設定の project_info がありません。")
    project_id = required_text(project.get("project_id"), "project_id")
    sender_id = project.get("project_number")
    if isinstance(sender_id, int) and not isinstance(sender_id, bool):
        sender_id = str(sender_id)
    sender_id = required_text(sender_id, "project_number")
    if not sender_id.isdigit():
        raise ValueError("Firebase設定の project_number が不正です。")

    clients = document.get("client")
    if not isinstance(clients, list):
        raise ValueError("Firebase設定の client がありません。")
    matching_clients = []
    for client in clients:
        if not isinstance(client, dict):
            continue
        info = client.get("client_info")
        if not isinstance(info, dict):
            continue
        android_info = info.get("android_client_info")
        if not isinstance(android_info, dict):
            continue
        if android_info.get("package_name") == package_name:
            matching_clients.append(client)
    if len(matching_clients) != 1:
        raise ValueError("対象パッケージのAndroidアプリ設定を1件だけ含めてください。")

    client = matching_clients[0]
    app_id = required_text(
        client["client_info"].get("mobilesdk_app_id"), "mobilesdk_app_id"
    )
    if not app_id.startswith(f"1:{sender_id}:android:"):
        raise ValueError("AndroidアプリIDとFirebaseプロジェクト番号が一致しません。")
    keys = client.get("api_key")
    if not isinstance(keys, list):
        raise ValueError("Androidアプリ用のFirebase APIキーがありません。")
    api_key = next(
        (
            key["current_key"].strip()
            for key in keys
            if isinstance(key, dict)
            and isinstance(key.get("current_key"), str)
            and key["current_key"].strip()
        ),
        None,
    )
    api_key = required_text(api_key, "api_key.current_key")
    bucket = project.get("storage_bucket")
    if bucket is not None and not isinstance(bucket, str):
        raise ValueError("Firebase設定の storage_bucket が不正です。")
    return {
        "MOCK_MODE": "false",
        "FIREBASE_API_KEY": api_key,
        "FIREBASE_APP_ID": app_id,
        "FIREBASE_PROJECT_ID": project_id,
        "FIREBASE_MESSAGING_SENDER_ID": sender_id,
        "FIREBASE_STORAGE_BUCKET": (bucket or "").strip(),
    }


def write_defines(output_path, defines):
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=output_path.parent, delete=False
        ) as temporary:
            temp_path = Path(temporary.name)
            json.dump(defines, temporary, ensure_ascii=False, indent=2)
            temporary.write("\n")
        os.replace(temp_path, output_path)
    finally:
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--package-name", default=DEFAULT_PACKAGE_NAME)
    args = parser.parse_args()
    try:
        document = json.loads(args.input.read_text(encoding="utf-8-sig"))
        defines = build_defines(document, args.package_name)
        write_defines(args.output, defines)
    except (ValueError, OSError, UnicodeError) as error:
        print(f"Firebase設定の準備に失敗しました: {error}", file=sys.stderr)
        return 1
    print("FirebaseのAndroid登録情報をビルド設定へ変換しました。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
