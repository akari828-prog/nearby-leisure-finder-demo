# 近くで、ちょっと遊ぼう。

現在地の近くで公開されているイベント情報を探す、Android専用Flutterアプリです。位置情報は検索ボタンを押した時だけ取得し、距離計算は端末内で行います。

## 機能

- Google ニュース RSS から最大10件の候補を取得
- 遊び・レジャーのキーワード判定を端末内で実行
- RSS本文に明記された住所だけを端末のジオコーダーで座標へ変換
- 位置から10km以内の候補を距離順で表示
- RSSに開催日時が明記されている場合だけ表示し、終了日時が過去と確認できるイベントを除外
- カードからHTTP/HTTPSの元記事を開く
- Google公式テスト広告を利用し、カード3回目ごとにロード済みの場合だけ全画面広告を表示
- RSS候補が見つからない時は実在しないイベントを作らず、再検索を案内

## 無料・プライバシー

このビルドはFirebase、Gemini API、APIキーを使いません。RSSの短い説明を端末内のキーワードで分類するため、AIのような柔軟な要約ではなく、キーワードによる誤判定や見逃しがあります。RSSに場所や開催日時が書かれていない場合は補わず、その情報を使う距離計算も行いません。

位置情報はユーザーが検索を押した時だけ取得します。GPS座標は端末内の距離計算に使い、Google ニュース RSSの検索語には市区町村などの地域名だけを含めます。常時・バックグラウンドの位置追跡はありません。

Gemini Developer APIの現行追加利用規約は一般消費者向けアプリでの利用を認めていないため、このアプリではGemini連携を外しています。Firebase設定やGemini APIキーも不要です。

## Flutter環境

- Flutter 3.47.x
- Dart 3.13.x
- Android SDK
- Android端末またはエミュレーター

## ビルド・実行

プロジェクトのルートで実行します。

```sh
flutter pub get
flutter analyze
flutter test
flutter run
flutter build apk
```

通常起動はRSSを使う実検索です。画面、距離表示、10kmフィルター、広告頻度、ブラウザー遷移をサンプルデータで試す場合は次のコマンドを使います。

```sh
flutter run --dart-define=MOCK_MODE=true
```

## PCを使わずAPKを入れる

スマートフォンのブラウザーで、このリポジトリの **Releases** ページを開き、最新の **Android free build** にある `nearby-leisure-free.apk` をダウンロードします。ダウンロードしたAPKを開いてインストールします。Androidが許可を求めた時は、APKを開いたブラウザーまたはファイルアプリに「不明なアプリのインストール」を許可してください。

このアプリはGoogle Play以外から配布する署名済みAPKです。実機でインストール・起動を確認できていないビルドには、その旨をリリース説明へ記載します。

## RSSを変更する

RSS URLと地域検索語は `lib/config/app_config.dart` の `AppConfig.feedsForArea` にまとめています。別のRSSを追加する時は返す `RssFeedConfig` のリストを編集します。各RSS提供元の利用条件を確認し、許可されている範囲だけを表示してください。RSS本文全体は再配信せず、短い説明、出典名、元記事へのリンクを使います。

## 広告を変更する

開発・配布用の既定値はGoogle公式テスト広告IDです。

- 広告ユニットID: `lib/config/ad_config.dart`
- テスト用AdMob App ID: `android/app/build.gradle.kts`

本番広告を使う場合は、独自のAdMob登録、同意管理、ポリシー確認を済ませてからテストIDを本番IDへ置き換えてください。現在のソースには本番広告IDを設定していません。

## Android権限

`android/app/src/main/AndroidManifest.xml` で使う権限は `INTERNET`、`ACCESS_FINE_LOCATION`、`ACCESS_COARSE_LOCATION` です。バックグラウンド位置情報と通知権限はありません。位置権限は検索を始めた時に要求します。

## GitHub Actions

ルートの `nearby_leisure_finder_flutter.zip` が完全なFlutterプロジェクトです。公開リポジトリのActionsワークフローが `flutter pub get`、`flutter analyze`、Release APKビルド、署名検証を行い、GitHub ReleasesへAPKを登録します。Firebase設定・Gemini APIキー・支払い方法は必要ありません。固定署名鍵はGitHub Actions Secretから読み込み、リポジトリへは含めません。
