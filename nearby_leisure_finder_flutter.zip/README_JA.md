# 近くで、ちょっと遊ぼう。

現在地周辺のレジャーイベントを検索するAndroid専用Flutterアプリです。位置情報は検索ボタンを押した時だけ取得し、距離計算は端末内で行います。

## 動作環境

- Flutter 3.47.x
- Dart 3.13.x
- Android StudioとAndroid SDK
- Android実機またはAndroid Emulator

初期状態はモックモードです。Firebaseや実RSSを設定する前でも、サンプル一覧、距離順、10kmフィルター、広告カウント、記事を開く処理を確認できます。表示されるサンプルイベントは実在の開催情報ではありません。

## 1. 取得とデモ起動

プロジェクトのルートで次を実行します。

~~~sh
flutter pub get
flutter analyze
flutter run
~~~

通常起動はモックモードです。モック検索は東京駅を基準に距離を計算します。カードをタップすると3回目、6回目、9回目……のタップだけ、事前ロード済みインタースティシャル広告があれば表示します。広告が未ロードなら待たずに記事を開きます。広告はGoogle公式テスト広告IDを使います。

実機で位置情報の許可UIやGPS取得も確認する場合は、ライブモードに切り替えてください。

## 2. FirebaseとGeminiの設定

課金しない運用では、Firebaseの **Sparkプラン** を使い、**Cloud Billingの請求先アカウントを紐付けません**。Firebase AI Logicでは **Gemini Developer API** バックエンドを選びます。初期モデル **gemini-3.5-flash-lite** は、この構成でテキストの入力・出力を無料枠内で利用できます。支払い方法の登録やBlazeプランへの変更は不要です。

無料枠には利用上限があります。上限を超えるとAPIが429等のエラーを返すため、アプリは検索エラーを表示して再検索できる状態へ戻ります。課金プランへの自動切り替えや、失敗したAIリクエストの自動再試行は実装していません。請求先アカウントを紐付けたプロジェクトではGeminiの利用が従量課金になるため、モデル名だけで無料になると判断しないでください。アプリ自身はFirebaseプロジェクトの請求設定を検査・変更しません。

料金条件の確認日：2026年10月5日。モデル変更時は次の公式資料で無料枠の対象とFirebase AI Logicのサポートを確認してください。

- https://firebase.google.com/docs/ai-logic/pricing?hl=ja
- https://ai.google.dev/gemini-api/docs/pricing
- https://firebase.google.com/docs/ai-logic/models?hl=ja

1. SparkプランのFirebaseプロジェクトでAndroidアプリを登録します。Androidのパッケージ名は **jp.example.nearbyleisurefinder** です。
2. Firebase CLIをインストールしてログインし、FlutterFire CLIをインストールします。

   ~~~sh
   npm install -g firebase-tools
   firebase login
   dart pub global activate flutterfire_cli
   ~~~

3. ルートでFirebaseアプリを設定します。

   ~~~sh
   flutterfire configure
   ~~~

   このコマンドが **lib/firebase_options.dart** をプロジェクトの設定で置き換えます。ライブモードにする前に、Firebase ConsoleでFirebase AI Logicを有効にしてください。Firebase AI LogicのGemini Developer APIバックエンドを使用します。DartソースにGemini APIキーは置きません。
4. Firebase ConsoleのApp CheckでAndroidアプリを登録します。開発時はアプリ起動ログに出るDebug providerのトークンをApp Checkへ登録してください。リリース時はPlay Integrityを使います。ライブモードでは起動時にこの設定を有効化します。
5. **lib/config/app_config.dart** の **useMockData** は **MOCK_MODE** のビルド定義で切り替わります。ライブ検索は次で実行します。

   ~~~sh
   flutter run --dart-define=MOCK_MODE=false
   ~~~

AIモデルは **lib/config/ai_config.dart** の **modelName** だけで変更します。初期値は無料枠に対応する **gemini-3.5-flash-lite** です。検索1回につき最大10件を1リクエストにまとめ、同一入力の解析結果はアプリ起動中のキャッシュを再利用します。Geminiに送る情報はRSSの公開情報だけで、利用者の現在地緯度・経度は送りません。

PCがない場合は **README_PHONE_JA.md** の手順を使います。FirebaseとAndroidアプリの登録はスマホのブラウザで行い、FlutterコマンドとAPK生成は無料ビルド用パッケージのGitHub Actionsで実行します。ワークフローはmockとliveを選択できます。Firebaseの登録JSONをGitHub Secretsで受け取り、端末のパッケージ名に対応する登録情報を検証してビルドへ渡します。署名鍵もSecretsから復元します。Firebaseプロジェクトの作成、AI Logicの有効化、App Checkの登録は、Firebase Consoleで行います。

同梱の **lib/firebase_options.dart** はビルド時の設定値を読み込みます。FlutterFire CLIを実行せずにAndroid登録情報を使う場合は、Firebaseからダウンロードした **google-services.json** を **android/app/google-services.json** に置き、次を実行します。

~~~sh
python3 tool/prepare_firebase_config.py --input android/app/google-services.json --output firebase-build-config.json
flutter pub get
flutter analyze
flutter run --dart-define-from-file=firebase-build-config.json
flutter build apk --release --dart-define-from-file=firebase-build-config.json
~~~

この変換はGemini APIキーを扱いません。FirebaseプロジェクトのAPIキー、アプリID、プロジェクトID、プロジェクト番号を使います。サービスアカウント秘密鍵も不要です。設定ファイルと署名鍵はソースへコミットしません。Android以外のプラットフォームと必須値が未設定の場合は、設定エラーとして扱います。**flutterfire configure** で生成した **firebase_options.dart** を使う場合は、そのファイル内の登録情報が使われます。

APKを直接インストールする場合のApp Checkは、Play Integrityの「Google Play以外に限定」向けの設定が必要です。公式資料では **PLAY_RECOGNIZED不要、LICENSED不要、デバイスの完全性を要求**する構成を案内しています。公開する署名証明書のSHA-256を登録し、実機からの認証を確認してからApp Checkの適用を有効にします。

https://firebase.google.com/docs/app-check/android/play-integrity-provider?hl=ja

## 3. RSSの設定

RSS URLと検索条件は **lib/config/app_config.dart** の **feedsForArea** にまとめています。初期設定では検索ボタンを押した時に端末で取得した地域情報から都道府県・市区町村名を作り、その地域名をGoogle News RSSの検索語に含めます。緯度・経度はRSS検索にもGeminiにも送信しません。Geminiに送信するのは最大10件のRSSタイトル、短縮した説明、出典名、記事公開日時だけです。

RSSソースは地域や開催情報の掲載状況によって検索結果が変わります。別のRSSを使う場合は **feedsForArea** が返す **RssFeedConfig** のリストを編集してください。公開・収益化の前に、各RSS提供元の利用条件と再配信条件を確認してください。アプリはRSS本文全体を一覧へ転載せず、元記事リンク、タイトル、短いAI要約、日時、場所、距離、出典を表示します。

## 4. AdMob設定

**lib/config/ad_config.dart** にバナーとインタースティシャルの広告ユニットIDがあります。デバッグはGoogle公式テスト広告IDを使います。本番の広告ユニットIDはリリースビルド時にDart defineで渡します。

~~~sh
flutter build apk --release --dart-define=MOCK_MODE=false --dart-define=ADMOB_BANNER_UNIT_ID=ca-app-pub-xxxxxxxx/yyyyyyyy --dart-define=ADMOB_INTERSTITIAL_UNIT_ID=ca-app-pub-xxxxxxxx/zzzzzzzz
~~~

AndroidのAdMob App IDは **android/app/build.gradle.kts** の **ADMOB_APP_ID** Gradleプロパティで設定します。初期値はGoogle公式テストApp IDです。本番値を設定する場合、Windowsでは **%USERPROFILE%\\.gradle\\gradle.properties**、macOS/Linuxでは **~/.gradle/gradle.properties** に次を追加してください。このファイルはソース管理へ含めません。

~~~properties
ADMOB_APP_ID=ca-app-pub-xxxxxxxx~aaaaaaaa
~~~

バナー広告のロード失敗では検索画面をエラーにしません。インタースティシャルは起動時に事前ロードし、表示後に次回分をロードします。表示失敗・ロード失敗・未ロードのいずれでも、選択した元記事を開けるようにしています。

## 5. Android権限と広告頻度

**android/app/src/main/AndroidManifest.xml** にはインターネット、ACCESS_FINE_LOCATION、ACCESS_COARSE_LOCATIONだけを宣言しています。バックグラウンド位置情報と通知権限はありません。位置権限は「現在地から探す」を押した時にだけ要求します。

イベントカードのタップはアプリ起動後から数え、3回目ごとに広告の表示対象になります。広告の準備が間に合わない場合は広告を飛ばして記事をすぐ開きます。処理中の重複タップは無視します。

## 6. ビルド

~~~sh
flutter pub get
flutter analyze
flutter run
flutter build apk
~~~

モックでAPKを作る場合は最後のコマンドの代わりに次を使います。

~~~sh
flutter build apk --dart-define=MOCK_MODE=true
~~~

FlutterFire CLIでFirebase設定を生成した場合、ライブ検索を含むAPKには **--dart-define=MOCK_MODE=false** を付けます。ビルド時設定を使う場合は **--dart-define-from-file=firebase-build-config.json** を付けます。このJSONには **MOCK_MODE=false** も含まれます。ここに含まれるRelease署名設定は端末確認用です。Google Playへ公開する際は、AndroidのRelease署名鍵を別途設定してください。

無料ビルド用パッケージのワークフローは、公開リポジトリの標準ランナーで実行し、成功したAPK、公開証明書情報、APKのSHA-256をGitHub Releasesへ保存します。Actionsの成果物ストレージやキャッシュは使いません。APKのリンクをスマホで開けば、そのままダウンロードしてインストールできます。ソースとAPKの公開はユーザーの許可後に行います。
