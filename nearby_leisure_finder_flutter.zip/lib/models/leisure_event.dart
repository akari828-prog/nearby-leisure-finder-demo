class LeisureEvent {
  const LeisureEvent({
    required this.title,
    required this.summary,
    required this.url,
    required this.address,
    required this.distanceKm,
    required this.sourceName,
    this.startTime,
    this.endTime,
    this.latitude,
    this.longitude,
  });

  final String title;
  final String summary;
  final String url;
  final String address;
  final double distanceKm;
  final DateTime? startTime;
  final DateTime? endTime;
  final String sourceName;

  /// Populated in mock mode for deterministic local distance testing.
  final double? latitude;
  final double? longitude;

  String get formattedDistance {
    final meters = (distanceKm * 1000).floor();
    if (distanceKm < 1) return '$meters m';
    return '${distanceKm.toStringAsFixed(1)} km';
  }

  LeisureEvent copyWith({double? distanceKm}) => LeisureEvent(
        title: title,
        summary: summary,
        url: url,
        address: address,
        distanceKm: distanceKm ?? this.distanceKm,
        startTime: startTime,
        endTime: endTime,
        sourceName: sourceName,
        latitude: latitude,
        longitude: longitude,
      );
}
