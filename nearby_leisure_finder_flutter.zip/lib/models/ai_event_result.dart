class AiEventResult {
  const AiEventResult({
    required this.index,
    required this.isLeisure,
    required this.summary,
    this.address,
    this.startTime,
    this.endTime,
  });

  final int index;
  final bool isLeisure;
  final String summary;
  final String? address;
  final DateTime? startTime;
  final DateTime? endTime;

  factory AiEventResult.fromJson(Map<String, Object?> json) {
    final index = json['index'];
    final isLeisure = json['isLeisure'];
    final summary = json['summary'];
    if (index is! int || isLeisure is! bool || summary is! String) {
      throw const FormatException('AIイベント項目の必須フィールドが不正です。');
    }

    return AiEventResult(
      index: index,
      isLeisure: isLeisure,
      summary: summary.trim(),
      address: _optionalString(json['address']),
      startTime: _parseIsoDate(json['startIso8601']),
      endTime: _parseIsoDate(json['endIso8601']),
    );
  }

  static String? _optionalString(Object? value) {
    if (value is! String || value.trim().isEmpty) return null;
    return value.trim();
  }

  static DateTime? _parseIsoDate(Object? value) {
    if (value is! String || value.trim().isEmpty) return null;
    return DateTime.tryParse(value.trim());
  }
}
