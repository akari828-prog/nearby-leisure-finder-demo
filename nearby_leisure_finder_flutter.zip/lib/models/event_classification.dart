class EventClassification {
  const EventClassification({
    required this.index,
    required this.isLeisure,
    required this.summary,
    this.address,
    this.startTime,
    this.endTime,
  });

  final int index;
  final bool isLeisure;
  final String summary;
  final String? address;
  final DateTime? startTime;
  final DateTime? endTime;
}
