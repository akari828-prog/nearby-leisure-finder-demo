class RssEvent {
  const RssEvent({
    required this.title,
    required this.description,
    required this.url,
    required this.sourceName,
    this.publishedAt,
  });

  final String title;
  final String description;
  final String url;
  final String sourceName;
  final DateTime? publishedAt;

  Map<String, Object?> toAiInput(int index) => <String, Object?>{
        'index': index,
        'title': title,
        'description': description,
        'source': sourceName,
        'publishedAt': publishedAt?.toIso8601String(),
      };
}
