class RssEvent {
  const RssEvent({
    required this.title,
    required this.description,
    required this.url,
    required this.sourceName,
    this.publishedAt,
  });

  final String title;
  final String description;
  final String url;
  final String sourceName;
  final DateTime? publishedAt;

}
