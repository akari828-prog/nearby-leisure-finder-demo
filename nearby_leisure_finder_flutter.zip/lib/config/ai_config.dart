class AiConfig {
  AiConfig._();

  /// Change this one value to switch supported Firebase AI Logic models.
  static const String modelName = 'gemini-3.5-flash-lite';
  static const double temperature = 0.1;
}
