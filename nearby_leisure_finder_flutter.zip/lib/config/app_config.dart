class RssFeedConfig {
  const RssFeedConfig({required this.name, required this.url});

  final String name;
  final Uri url;
}

class AppConfig {
  AppConfig._();

  /// The default build searches RSS and classifies events on-device.
  /// Set --dart-define=MOCK_MODE=true to exercise the UI with sample events.
  static const bool useMockData =
      bool.fromEnvironment('MOCK_MODE', defaultValue: false);

  static const int maximumRssItems = 10;
  static const int maximumDescriptionCharacters = 1200;
  static const int maximumSummaryCharacters = 240;
  static const double searchRadiusKm = 10;
  static const Duration rssTimeout = Duration(seconds: 15);
  static const Duration geocodingTimeout = Duration(seconds: 8);

  /// Google News RSS search is the default source. Add/remove feeds here.
  /// Only the approximate prefecture/city name is placed in the search query.
  static List<RssFeedConfig> feedsForArea(String? area) {
    final normalizedArea = area?.trim().replaceAll(RegExp(r'\s+'), ' ') ?? '';
    final localityTerm =
        normalizedArea.isEmpty ? '' : '"$normalizedArea" ';
    final query =
        '$localityTerm(イベント OR 祭り OR 花火 OR マルシェ OR 展示会 OR 観光イベント OR イルミネーション) when:30d';
    final url = Uri.https(
      'news.google.com',
      '/rss/search',
      <String, String>{
        'q': query,
        'hl': 'ja',
        'gl': 'JP',
        'ceid': 'JP:ja',
      },
    );
    return <RssFeedConfig>[
      RssFeedConfig(name: 'Google ニュース RSS', url: url),
    ];
  }
}
