import 'package:flutter/foundation.dart';

class AdConfig {
  AdConfig._();

  static const String testBannerUnitId =
      'ca-app-pub-3940256099942544/6300978111';
  static const String testInterstitialUnitId =
      'ca-app-pub-3940256099942544/1033173712';

  /// Fill these only after registering production AdMob ad units.
  static const String productionBannerUnitId = String.fromEnvironment(
    'ADMOB_BANNER_UNIT_ID',
    defaultValue: '',
  );
  static const String productionInterstitialUnitId = String.fromEnvironment(
    'ADMOB_INTERSTITIAL_UNIT_ID',
    defaultValue: '',
  );

  static String get bannerUnitId =>
      kReleaseMode && productionBannerUnitId.isNotEmpty
          ? productionBannerUnitId
          : testBannerUnitId;

  static String get interstitialUnitId =>
      kReleaseMode && productionInterstitialUnitId.isNotEmpty
          ? productionInterstitialUnitId
          : testInterstitialUnitId;
}
