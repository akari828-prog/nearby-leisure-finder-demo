import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

/// Android configuration is supplied at build time, without source credentials.
/// FlutterFire CLI can also replace this file with generated project options.
class DefaultFirebaseOptions {
  DefaultFirebaseOptions._();

  static const String _apiKey = String.fromEnvironment('FIREBASE_API_KEY');
  static const String _appId = String.fromEnvironment('FIREBASE_APP_ID');
  static const String _projectId = String.fromEnvironment('FIREBASE_PROJECT_ID');
  static const String _messagingSenderId =
      String.fromEnvironment('FIREBASE_MESSAGING_SENDER_ID');
  static const String _storageBucket =
      String.fromEnvironment('FIREBASE_STORAGE_BUCKET');

  static FirebaseOptions get currentPlatform {
    if (kIsWeb || defaultTargetPlatform != TargetPlatform.android) {
      throw UnsupportedError('このアプリはAndroid専用です。');
    }
    return android;
  }

  static FirebaseOptions get android {
    if (_apiKey.trim().isEmpty ||
        _appId.trim().isEmpty ||
        _projectId.trim().isEmpty ||
        _messagingSenderId.trim().isEmpty) {
      throw StateError(
        'Firebaseの登録情報がありません。README_JA.mdのFirebase設定に従ってビルドしてください。',
      );
    }
    return FirebaseOptions(
      apiKey: _apiKey,
      appId: _appId,
      messagingSenderId: _messagingSenderId,
      projectId: _projectId,
      storageBucket: _storageBucket.isEmpty ? null : _storageBucket,
    );
  }
}
