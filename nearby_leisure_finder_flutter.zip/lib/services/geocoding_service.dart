import 'package:geocoding/geocoding.dart';

import '../config/app_config.dart';
import 'location_service.dart';

class GeoCoordinates {
  const GeoCoordinates({required this.latitude, required this.longitude});

  final double latitude;
  final double longitude;
}

class GeocodingService {
  Future<String?> getAreaLabel(DeviceLocation location) async {
    try {
      final placemarks = await placemarkFromCoordinates(
        location.latitude,
        location.longitude,
      ).timeout(AppConfig.geocodingTimeout);
      if (placemarks.isEmpty) return null;
      final place = placemarks.first;
      final parts = <String>[
        if ((place.administrativeArea ?? '').trim().isNotEmpty)
          place.administrativeArea!.trim(),
        if ((place.locality ?? '').trim().isNotEmpty) place.locality!.trim(),
      ];
      if (parts.isNotEmpty) return parts.toSet().join(' ');
      final fallback = place.subAdministrativeArea?.trim() ?? '';
      return fallback.isEmpty ? null : fallback;
    } catch (_) {
      return null;
    }
  }

  /// Resolves addresses sequentially and caches duplicate strings for this search.
  Future<Map<String, GeoCoordinates?>> geocodeSequentially(
    Iterable<String> addresses,
  ) async {
    final result = <String, GeoCoordinates?>{};
    final cache = <String, GeoCoordinates?>{};
    final queried = <String>{};

    for (final rawAddress in addresses) {
      final address = rawAddress.trim();
      if (address.isEmpty) continue;
      final key = address.toLowerCase();
      if (!queried.add(key)) continue;
      try {
        final locations = await locationFromAddress(address)
            .timeout(AppConfig.geocodingTimeout);
        cache[key] = locations.isEmpty
            ? null
            : GeoCoordinates(
                latitude: locations.first.latitude,
                longitude: locations.first.longitude,
              );
      } catch (_) {
        cache[key] = null;
      }
    }

    for (final rawAddress in addresses) {
      final address = rawAddress.trim();
      if (address.isNotEmpty) {
        result[address.toLowerCase()] = cache[address.toLowerCase()];
      }
    }
    return result;
  }
}
