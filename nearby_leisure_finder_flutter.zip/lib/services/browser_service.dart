import 'package:url_launcher/url_launcher.dart';

class BrowserService {
  Uri? safeHttpUri(String rawUrl) {
    final uri = Uri.tryParse(rawUrl.trim());
    if (uri == null ||
        !uri.isAbsolute ||
        uri.host.isEmpty ||
        (uri.scheme != 'http' && uri.scheme != 'https')) {
      return null;
    }
    return uri;
  }

  Future<bool> openUrl(String rawUrl) async {
    final uri = safeHttpUri(rawUrl);
    if (uri == null) return false;

    for (final mode in <LaunchMode>[
      LaunchMode.inAppBrowserView,
      LaunchMode.inAppWebView,
      LaunchMode.externalApplication,
    ]) {
      try {
        if (await launchUrl(uri, mode: mode)) return true;
      } catch (_) {
        // Try the next supported launch mode.
      }
    }
    return false;
  }
}
