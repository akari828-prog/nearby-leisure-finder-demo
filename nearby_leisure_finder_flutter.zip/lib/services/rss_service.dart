import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';

import '../config/app_config.dart';
import '../models/rss_event.dart';

class RssFetchException implements Exception {
  const RssFetchException(this.message);

  final String message;

  @override
  String toString() => message;
}

class RssService {
  RssService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  Future<List<RssEvent>> fetchLatestEvents({String? area}) async {
    final feeds = AppConfig.feedsForArea(area);
    final eventsByUrl = <String, RssEvent>{};
    var successfulFeedCount = 0;

    for (final feed in feeds) {
      try {
        final response = await _client
            .get(
              feed.url,
              headers: const <String, String>{
                'Accept':
                    'application/rss+xml, application/atom+xml, application/xml, text/xml',
                'User-Agent': 'NearbyLeisureFinder/1.0 (Flutter Android app)',
              },
            )
            .timeout(AppConfig.rssTimeout);
        if (response.statusCode < 200 || response.statusCode >= 300) {
          continue;
        }

        final body = utf8.decode(response.bodyBytes, allowMalformed: true);
        final parsed = _parseFeed(body, fallbackSource: feed.name);
        successfulFeedCount += 1;
        for (final event in parsed) {
          final canonicalUrl = _canonicalizeUrl(event.url);
          if (canonicalUrl.isNotEmpty) {
            eventsByUrl.putIfAbsent(canonicalUrl, () => event);
          }
        }
      } catch (_) {
        // A single feed can be malformed or temporarily unavailable.
      }
    }

    if (successfulFeedCount == 0) {
      throw const RssFetchException(
        'イベント情報を取得できませんでした。ネット接続を確認して、時間をおいて再検索してください。',
      );
    }

    final items = eventsByUrl.values.toList()
      ..sort((a, b) {
        final aDate = a.publishedAt;
        final bDate = b.publishedAt;
        if (aDate == null && bDate == null) return 0;
        if (aDate == null) return 1;
        if (bDate == null) return -1;
        return bDate.compareTo(aDate);
      });
    return items.take(AppConfig.maximumRssItems).toList(growable: false);
  }

  List<RssEvent> _parseFeed(String xml, {required String fallbackSource}) {
    final document = XmlDocument.parse(xml);
    final root = document.rootElement;
    final rootName = root.name.local.toLowerCase();
    final isAtom = rootName == 'feed';
    final channel = isAtom
        ? root
        : root.descendantElements.firstWhere(
            (element) => element.name.local.toLowerCase() == 'channel',
            orElse: () => root,
          );
    final channelTitle = _childText(channel, 'title');
    final entries = root.descendantElements
        .where((element) {
          final name = element.name.local.toLowerCase();
          return isAtom ? name == 'entry' : name == 'item';
        })
        .toList(growable: false);

    return entries.map((entry) {
      final title = _childText(entry, 'title').trim();
      final description = _cleanDescription(
        _childText(entry, 'description').isNotEmpty
            ? _childText(entry, 'description')
            : _childText(entry, 'summary'),
      );
      final link = _entryLink(entry, isAtom: isAtom);
      final source = _childText(entry, 'source').trim();
      final publicationDate = _parseDate(
        _childText(entry, 'pubDate').isNotEmpty
            ? _childText(entry, 'pubDate')
            : _childText(entry, 'published').isNotEmpty
                ? _childText(entry, 'published')
                : _childText(entry, 'updated'),
      );

      return RssEvent(
        title: title,
        description: description,
        url: link,
        sourceName: source.isNotEmpty
            ? source
            : channelTitle.isNotEmpty
                ? channelTitle
                : fallbackSource,
        publishedAt: publicationDate,
      );
    }).where((event) => event.title.isNotEmpty && event.url.isNotEmpty).toList(
          growable: false,
        );
  }

  String _entryLink(XmlElement entry, {required bool isAtom}) {
    final links = entry.descendantElements.where(
      (element) => element.name.local.toLowerCase() == 'link',
    );
    if (links.isEmpty) return '';
    final linkElement = links.first;
    final href = linkElement.getAttribute('href');
    if (href != null && href.trim().isNotEmpty) return href.trim();
    if (isAtom) return '';
    return linkElement.innerText.trim();
  }

  String _childText(XmlElement parent, String localName) {
    for (final child in parent.childElements) {
      if (child.name.local.toLowerCase() == localName.toLowerCase()) {
        return child.innerText.trim();
      }
    }
    return '';
  }

  String _cleanDescription(String raw) {
    var text = raw
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&#160;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&apos;', "'")
        .replaceAllMapped(
          RegExp(r'&#(x[0-9a-fA-F]+|\d+);'),
          (match) {
            final entity = match.group(1)!;
            final codePoint = entity.toLowerCase().startsWith('x')
                ? int.tryParse(entity.substring(1), radix: 16)
                : int.tryParse(entity);
            if (codePoint == null ||
                codePoint < 0 ||
                codePoint > 0x10ffff ||
                (codePoint >= 0xd800 && codePoint <= 0xdfff)) {
              return ' ';
            }
            return String.fromCharCode(codePoint);
          },
        )
        .replaceAll(
          RegExp(r'<(script|style)\b[^>]*>[\s\S]*?</\1>', caseSensitive: false),
          ' ',
        )
        .replaceAll(RegExp(r'<[^>]*>'), ' ');

    text = text
        .replaceAll(RegExp(r'[\r\n\t]+'), ' ')
        .replaceAll(RegExp(r'\s{2,}'), ' ')
        .trim();
    if (text.length > AppConfig.maximumDescriptionCharacters) {
      text = text.substring(0, AppConfig.maximumDescriptionCharacters);
    }
    return text;
  }

  DateTime? _parseDate(String value) {
    if (value.isEmpty) return null;
    return DateTime.tryParse(value) ?? _tryParseRfc822(value);
  }

  DateTime? _tryParseRfc822(String value) {
    try {
      return DateFormatFallback.parse(value);
    } catch (_) {
      return null;
    }
  }

  String _canonicalizeUrl(String value) {
    final uri = Uri.tryParse(value.trim());
    if (uri == null ||
        !uri.hasAuthority ||
        (uri.scheme != 'https' && uri.scheme != 'http')) {
      return '';
    }
    return uri.replace(fragment: '').toString();
  }

  void dispose() => _client.close();
}

class DateFormatFallback {
  DateFormatFallback._();

  static DateTime? parse(String input) {
    final match = RegExp(
      r'^(?:[A-Za-z]{3},?\s+)?(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})\s+(\d{2}):(\d{2})(?::(\d{2}))?\s+([+-]\d{4}|GMT|UTC)$',
      caseSensitive: false,
    ).firstMatch(input.trim());
    if (match == null) return null;

    const months = <String, int>{
      'jan': 1,
      'feb': 2,
      'mar': 3,
      'apr': 4,
      'may': 5,
      'jun': 6,
      'jul': 7,
      'aug': 8,
      'sep': 9,
      'oct': 10,
      'nov': 11,
      'dec': 12,
    };
    final month = months[match.group(2)!.toLowerCase()];
    if (month == null) return null;

    final day = int.parse(match.group(1)!);
    final year = int.parse(match.group(3)!);
    final hour = int.parse(match.group(4)!);
    final minute = int.parse(match.group(5)!);
    final second = int.tryParse(match.group(6) ?? '0') ?? 0;
    final zone = match.group(7)!.toUpperCase();
    var utc = DateTime.utc(year, month, day, hour, minute, second);
    if (zone != 'GMT' && zone != 'UTC') {
      final sign = zone.startsWith('-') ? -1 : 1;
      final offsetHours = int.parse(zone.substring(1, 3));
      final offsetMinutes = int.parse(zone.substring(3, 5));
      utc = utc.subtract(
        Duration(minutes: sign * (offsetHours * 60 + offsetMinutes)),
      );
    }
    return utc;
  }
}
