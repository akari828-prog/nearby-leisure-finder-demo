import '../config/app_config.dart';
import '../models/event_classification.dart';
import '../models/rss_event.dart';

/// Classifies short RSS snippets using transparent on-device word lists.
/// It never sends RSS or location information to an AI service.
class LocalEventClassifier {
  const LocalEventClassifier();

  static const List<String> _leisureWords = <String>[
    'イベント',
    '祭り',
    'まつり',
    'お祭り',
    '花火',
    'マルシェ',
    'フリーマーケット',
    'フリマ',
    '蚤の市',
    '展示会',
    '美術展',
    '美術館',
    '博物館',
    '動物園',
    '水族館',
    '観光イベント',
    '観光スポット',
    'グルメフェス',
    'グルメイベント',
    '音楽祭',
    'コンサート',
    '地域イベント',
    '子ども向け',
    '子供向け',
    '家族向け',
    'スポーツ観戦',
    '季節イベント',
    'イルミネーション',
    '体験イベント',
    '体験会',
    'フェス',
    'フェスティバル',
  ];

  static const List<String> _nonLeisureWords = <String>[
    '勉強会',
    'ビジネスセミナー',
    'セミナー',
    '企業説明会',
    '会社説明会',
    '採用説明会',
    '求人イベント',
    '転職イベント',
    '投資セミナー',
    '営業セミナー',
    '業務研修',
    '研修会',
    '学術研究会',
    '研究会',
    'オンライン開催',
    'オンラインイベント',
    'ウェビナー',
  ];

  List<EventClassification> classify(List<RssEvent> events) {
    return events.asMap().entries.map((entry) {
      final event = entry.value;
      final sourceText = '${event.title} ${event.description}';
      final isLeisure = _classifyLeisure(sourceText);
      final dateRange = isLeisure ? _extractEventDates(event.description) : null;
      return EventClassification(
        index: entry.key,
        isLeisure: isLeisure,
        summary: isLeisure ? _shortSummary(event.description) : '',
        address: isLeisure ? _extractAddress(event.description) : null,
        startTime: dateRange?.start,
        endTime: dateRange?.end,
      );
    }).toList(growable: false);
  }

  bool _classifyLeisure(String text) {
    if (_nonLeisureWords.any(text.contains)) return false;
    return _leisureWords.any(text.contains);
  }

  String _shortSummary(String description) {
    final normalized = description
        .replaceAll(RegExp(r'\s+'), ' ')
        .replaceAll(RegExp(r'^(?:概要|内容|詳細)\s*[:：]\s*'), '')
        .trim();
    if (normalized.length <= AppConfig.maximumSummaryCharacters) {
      return normalized;
    }
    final cutoff = normalized.lastIndexOf('。', AppConfig.maximumSummaryCharacters);
    if (cutoff >= 50) return normalized.substring(0, cutoff + 1);
    return '${normalized.substring(0, AppConfig.maximumSummaryCharacters).trimRight()}…';
  }

  String? _extractAddress(String text) {
    final match = RegExp(
      r'(?:北海道|東京都|(?:京都|大阪)府|[一-龥々〆ヵヶ]{2,8}県)[^。、，,\n]{0,35}?(?:市|区|町|村)[^。、，,\n]{0,18}',
    ).firstMatch(text);
    final address = match?.group(0)?.trim();
    if (address == null || address.isEmpty) return null;
    return address
        .replaceFirst(RegExp(r'^(?:会場|開催場所|開催地|場所)\s*[:：]\s*'), '')
        .trim();
  }

  _EventDateRange? _extractEventDates(String text) {
    final labeledRange = RegExp(
      r'(?:開催日時|開催期間|開催日|日程|会期)\s*[:：]?\s*([^。\n]{1,60})',
    ).firstMatch(text)?.group(1);
    if (labeledRange == null) return null;

    final dates = RegExp(
      r'(\d{4})年\s*(\d{1,2})月\s*(\d{1,2})日',
    ).allMatches(labeledRange).toList(growable: false);
    if (dates.isEmpty) return null;

    final times = RegExp(r'(\d{1,2}):(\d{2})')
        .allMatches(labeledRange)
        .toList(growable: false);
    final timesAreUnambiguous =
        dates.length == 1 ? times.isNotEmpty : times.length >= 2;
    final first = _dateFromMatch(
      dates.first,
      times,
      includeTime: timesAreUnambiguous,
    );
    if (first == null) return null;
    DateTime? end;
    if (dates.length > 1) {
      end = _dateFromMatch(
        dates[1],
        times,
        isEnd: true,
        includeTime: timesAreUnambiguous,
      );
    } else {
      final timeRange = RegExp(
        r'(\d{1,2}):(\d{2})\s*[〜～~\-―–]\s*(\d{1,2}):(\d{2})',
      ).firstMatch(labeledRange);
      if (timeRange != null) {
        end = DateTime(
          first.year,
          first.month,
          first.day,
          int.parse(timeRange.group(3)!),
          int.parse(timeRange.group(4)!),
        );
      }
    }
    return _EventDateRange(start: first, end: end);
  }

  DateTime? _dateFromMatch(
    RegExpMatch match,
    List<RegExpMatch> times, {
    bool isEnd = false,
    bool includeTime = true,
  }) {
    final year = int.tryParse(match.group(1) ?? '');
    final month = int.tryParse(match.group(2) ?? '');
    final day = int.tryParse(match.group(3) ?? '');
    if (year == null || month == null || day == null) return null;

    final time = !includeTime || times.isEmpty
        ? null
        : (isEnd && times.length > 1 ? times.last : times.first);
    final hour = time == null ? 0 : int.parse(time.group(1)!);
    final minute = time == null ? 0 : int.parse(time.group(2)!);
    if (hour > 23 || minute > 59) return null;
    final date = DateTime(
      year,
      month,
      day,
      hour,
      minute,
    );
    if (date.year != year || date.month != month || date.day != day) {
      return null;
    }
    return date;
  }
}

class _EventDateRange {
  const _EventDateRange({required this.start, this.end});

  final DateTime start;
  final DateTime? end;
}
