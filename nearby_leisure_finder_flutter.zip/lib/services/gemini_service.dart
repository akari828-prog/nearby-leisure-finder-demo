import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:firebase_ai/firebase_ai.dart';

import '../config/ai_config.dart';
import '../config/app_config.dart';
import '../models/ai_event_result.dart';
import '../models/rss_event.dart';

class GeminiService {
  GeminiService({this.startupError});

  final String? startupError;
  final Map<String, List<AiEventResult>> _sessionCache =
      <String, List<AiEventResult>>{};

  static const String _systemInstruction = '''
あなたは日本のイベント情報を整理する分類器です。入力されたRSS情報に書かれている事実だけを使ってください。
レジャー・遊び目的のイベント（祭り、花火、マルシェ、フリーマーケット、展示、美術展、博物館、動物園、水族館、観光、グルメ、音楽、地域、子ども・家族、スポーツ観戦、季節、イルミネーション、体験）は isLeisure=true とします。
IT勉強会、ビジネス・投資・営業セミナー、企業説明会、採用・求人・転職、業務研修、学術研究会、オンラインのみ、または判断できないものは isLeisure=false とします。
住所、開催日時、施設、参加条件などを推測で作らないでください。本文に具体的な会場住所がない場合は address を null にしてください。開催日時が本文に明記されていない場合は startIso8601 と endIso8601 を null にしてください。RSSのpublishedAtは記事の配信日時であり、開催日時ではありません。
summaryは日本語で、本文から確認できる内容だけを最大3行で簡潔にまとめます。urlやtitleを生成・変更しないでください。
各入力のindexをそのまま返し、入力にないイベントやindexを作らないでください。
''';

  Future<List<AiEventResult>> analyze(List<RssEvent> events) async {
    if (startupError != null) {
      throw StateError('Firebaseの初期化に失敗しました。$startupError');
    }
    if (events.isEmpty) return const <AiEventResult>[];

    final payload = events
        .asMap()
        .entries
        .map((entry) => entry.value.toAiInput(entry.key))
        .toList(growable: false);
    final payloadText = jsonEncode(payload);
    final cacheKey = sha256.convert(utf8.encode(payloadText)).toString();
    final cached = _sessionCache[cacheKey];
    if (cached != null) return cached;

    final responseSchema = Schema.array(
      maxItems: AppConfig.maximumRssItems,
      items: Schema.object(
        properties: <String, Schema>{
          'index': Schema.integer(),
          'isLeisure': Schema.boolean(),
          'summary': Schema.string(),
          'address': Schema.string(nullable: true),
          'startIso8601': Schema.string(nullable: true),
          'endIso8601': Schema.string(nullable: true),
        },
      ),
    );
    final model = FirebaseAI.googleAI().generativeModel(
      model: AiConfig.modelName,
      systemInstruction: Content.system(_systemInstruction),
      generationConfig: GenerationConfig(
        responseMimeType: 'application/json',
        responseSchema: responseSchema,
        temperature: AiConfig.temperature,
      ),
    );
    final prompt = '''
以下はRSSから取得した最大${AppConfig.maximumRssItems}件のイベント候補です。
配列の各要素について、index, isLeisure, summary, address, startIso8601, endIso8601を返してください。
住所と日時は記事本文に根拠がある場合だけ返し、それ以外はnullにしてください。日時は根拠がある場合ISO 8601形式にします。
JSON配列のみを返してください。

RSS候補:
$payloadText
''';

    final response = await model
        .generateContent(<Content>[Content.text(prompt)])
        .timeout(AppConfig.aiTimeout);
    final responseText = response.text;
    if (responseText == null || responseText.trim().isEmpty) {
      throw const FormatException('Geminiから空の応答が返されました。');
    }

    final Object? decoded;
    try {
      decoded = jsonDecode(responseText);
    } on FormatException {
      throw const FormatException('GeminiのJSON応答を解析できませんでした。');
    }
    if (decoded is! List) {
      throw const FormatException('Geminiの応答がJSON配列ではありません。');
    }

    final parsed = <AiEventResult>[];
    final acceptedIndexes = <int>{};
    for (final item in decoded) {
      if (item is! Map) continue;
      try {
        final result = AiEventResult.fromJson(Map<String, Object?>.from(item));
        if (result.index < 0 ||
            result.index >= events.length ||
            !acceptedIndexes.add(result.index)) {
          continue;
        }
        parsed.add(result);
      } catch (_) {
        // Ignore a malformed row without discarding valid rows.
      }
    }

    final immutableResults = List<AiEventResult>.unmodifiable(parsed);
    _sessionCache[cacheKey] = immutableResults;
    if (_sessionCache.length > 20) {
      _sessionCache.remove(_sessionCache.keys.first);
    }
    return immutableResults;
  }
}
