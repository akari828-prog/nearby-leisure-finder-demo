import 'dart:async';

import 'package:geolocator/geolocator.dart';

class DeviceLocation {
  const DeviceLocation({required this.latitude, required this.longitude});

  final double latitude;
  final double longitude;
}

enum LocationIssue {
  serviceDisabled,
  permissionDenied,
  permissionDeniedForever,
  timeout,
  unavailable,
}

class LocationServiceException implements Exception {
  const LocationServiceException(this.issue);

  final LocationIssue issue;

  String get message => switch (issue) {
        LocationIssue.serviceDisabled =>
          '位置情報サービスがOFFです。端末の位置情報をONにして再検索してください。',
        LocationIssue.permissionDenied =>
          '位置情報の利用が許可されていません。許可してから再検索してください。',
        LocationIssue.permissionDeniedForever =>
          '位置情報が許可されていません。設定から位置情報を許可してください。',
        LocationIssue.timeout =>
          '現在地を取得できませんでした。電波状況を確認して再検索してください。',
        LocationIssue.unavailable =>
          '現在地を取得できませんでした。端末の設定を確認して再検索してください。',
      };
}

class LocationService {
  Future<DeviceLocation> getCurrentLocation() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw const LocationServiceException(LocationIssue.serviceDisabled);
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.deniedForever) {
      throw const LocationServiceException(
        LocationIssue.permissionDeniedForever,
      );
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.unableToDetermine) {
      throw const LocationServiceException(LocationIssue.permissionDenied);
    }

    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 18),
        ),
      );
      return DeviceLocation(
        latitude: position.latitude,
        longitude: position.longitude,
      );
    } on TimeoutException {
      throw const LocationServiceException(LocationIssue.timeout);
    } on LocationServiceException {
      rethrow;
    } catch (_) {
      throw const LocationServiceException(LocationIssue.unavailable);
    }
  }

  Future<bool> openAppSettings() => Geolocator.openAppSettings();

  Future<bool> openLocationSettings() => Geolocator.openLocationSettings();
}
