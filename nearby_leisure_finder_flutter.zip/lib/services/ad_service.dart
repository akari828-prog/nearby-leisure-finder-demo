import 'dart:async';

import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../config/ad_config.dart';

class AdService {
  InterstitialAd? _loadedInterstitial;
  bool _isLoading = false;
  bool _isShowing = false;
  bool _isDisposed = false;
  bool _navigationInProgress = false;
  int _eventTapCount = 0;
  String? _lastEventUrl;
  DateTime? _lastEventTapAt;

  int get eventTapCount => _eventTapCount;

  void preloadInterstitial() {
    if (_isDisposed || _isLoading || _isShowing || _loadedInterstitial != null) {
      return;
    }
    _isLoading = true;
    try {
      unawaited(InterstitialAd.load(
        adUnitId: AdConfig.interstitialUnitId,
        request: const AdRequest(),
        adLoadCallback: InterstitialAdLoadCallback(
          onAdLoaded: (ad) {
            _isLoading = false;
            if (_isDisposed) {
              unawaited(ad.dispose());
              return;
            }
            _loadedInterstitial = ad;
          },
          onAdFailedToLoad: (_) {
            _isLoading = false;
          },
        ),
      ).catchError((Object _) {
        _isLoading = false;
      }));
    } catch (_) {
      _isLoading = false;
    }
  }

  /// Runs a card action after the third, sixth, ninth, ... tap's ad is closed.
  /// If no ad is already ready, the action runs immediately.
  Future<bool?> handleEventTap({
    required String eventUrl,
    required Future<bool> Function() openEvent,
  }) async {
    if (_navigationInProgress || _isDisposed) return null;
    final now = DateTime.now();
    final lastTapAt = _lastEventTapAt;
    if (_lastEventUrl == eventUrl &&
        lastTapAt != null &&
        now.difference(lastTapAt) < const Duration(milliseconds: 900)) {
      return null;
    }
    _navigationInProgress = true;
    _lastEventUrl = eventUrl;
    _lastEventTapAt = now;
    _eventTapCount += 1;
    final isAdTap = _eventTapCount % 3 == 0;

    try {
      if (isAdTap) await _showLoadedInterstitialOrSkip();
      return await openEvent();
    } finally {
      _navigationInProgress = false;
      if (isAdTap) preloadInterstitial();
    }
  }

  Future<void> _showLoadedInterstitialOrSkip() async {
    final ad = _loadedInterstitial;
    if (ad == null || _isShowing) return;

    _loadedInterstitial = null;
    _isShowing = true;
    final completer = Completer<void>();
    var callbackHandled = false;

    void finish(InterstitialAd usedAd) {
      if (callbackHandled) return;
      callbackHandled = true;
      unawaited(usedAd.dispose());
      _isShowing = false;
      if (!completer.isCompleted) completer.complete();
    }

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: finish,
      onAdFailedToShowFullScreenContent: (usedAd, _) => finish(usedAd),
    );

    try {
      unawaited(
        ad.show().catchError((Object _) {
          finish(ad);
        }),
      );
    } catch (_) {
      finish(ad);
    }
    await completer.future;
  }

  void dispose() {
    if (_isDisposed) return;
    _isDisposed = true;
    final loadedAd = _loadedInterstitial;
    if (loadedAd != null) unawaited(loadedAd.dispose());
    _loadedInterstitial = null;
  }
}
