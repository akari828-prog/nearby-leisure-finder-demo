import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'providers/ad_provider.dart';
import 'services/ad_service.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final adService = AdService();
  var adsInitialized = false;
  try {
    await MobileAds.instance.initialize();
    adsInitialized = true;
  } catch (_) {
    // Ad failures do not prevent the event search screen from opening.
  }
  if (adsInitialized) adService.preloadInterstitial();

  runApp(
    ProviderScope(
      overrides: [
        adServiceProvider.overrideWith((ref) {
          ref.onDispose(adService.dispose);
          return adService;
        }),
      ],
      child: const NearbyLeisureApp(),
    ),
  );
}

class NearbyLeisureApp extends StatelessWidget {
  const NearbyLeisureApp({super.key});

  @override
  Widget build(BuildContext context) {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF337A6F),
      brightness: Brightness.light,
    );
    return MaterialApp(
      title: '近くで、ちょっと遊ぼう。',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: colorScheme,
        scaffoldBackgroundColor: colorScheme.surface,
        visualDensity: VisualDensity.standard,
      ),
      home: const HomeScreen(),
    );
  }
}
