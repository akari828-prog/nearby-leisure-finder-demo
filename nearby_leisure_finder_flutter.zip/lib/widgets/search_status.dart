import 'package:flutter/material.dart';

import '../providers/event_search_provider.dart';

class SearchStatus extends StatelessWidget {
  const SearchStatus({required this.searchState, super.key});

  final EventSearchState searchState;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isError = searchState.stage == SearchStage.error;
    final color = isError
        ? theme.colorScheme.error
        : theme.colorScheme.onSurfaceVariant;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: isError
            ? theme.colorScheme.errorContainer
            : theme.colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (searchState.isSearching)
            SizedBox(
              width: 19,
              height: 19,
              child: CircularProgressIndicator(
                strokeWidth: 2.2,
                color: theme.colorScheme.primary,
              ),
            )
          else
            Icon(
              isError ? Icons.error_outline : Icons.info_outline,
              size: 20,
              color: color,
            ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  searchState.stage.japaneseLabel,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: color,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (searchState.errorMessage case final message?) ...<Widget>[
                  const SizedBox(height: 4),
                  Text(
                    message,
                    style: theme.textTheme.bodySmall?.copyWith(color: color),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
