import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../config/ad_config.dart';

class BannerAdWidget extends StatefulWidget {
  const BannerAdWidget({super.key});

  @override
  State<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends State<BannerAdWidget> {
  BannerAd? _bannerAd;
  AnchoredAdaptiveBannerAdSize? _adSize;
  int? _requestedWidth;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final width = MediaQuery.sizeOf(context).width.truncate();
    if (_requestedWidth != width) {
      _requestedWidth = width;
      unawaited(_loadBanner(width));
    }
  }

  Future<void> _loadBanner(int width) async {
    final AnchoredAdaptiveBannerAdSize? size;
    try {
      size = await AdSize.getLargeAnchoredAdaptiveBannerAdSize(
        width,
      );
    } catch (_) {
      return;
    }
    if (!mounted || size == null || width != _requestedWidth) return;

    final oldAd = _bannerAd;
    _bannerAd = null;
    if (oldAd != null) unawaited(oldAd.dispose());

    final ad = BannerAd(
      adUnitId: AdConfig.bannerUnitId,
      size: size,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (loadedAd) {
          if (!mounted || loadedAd != _bannerAd) return;
          setState(() => _adSize = size);
        },
        onAdFailedToLoad: (failedAd, _) {
          unawaited(failedAd.dispose());
          if (!mounted || failedAd != _bannerAd) return;
          setState(() {
            _bannerAd = null;
            _adSize = null;
          });
        },
      ),
    );
    _bannerAd = ad;
    try {
      await ad.load();
    } catch (_) {
      unawaited(ad.dispose());
      if (!mounted || ad != _bannerAd) return;
      setState(() {
        _bannerAd = null;
        _adSize = null;
      });
    }
  }

  @override
  void dispose() {
    final ad = _bannerAd;
    if (ad != null) unawaited(ad.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ad = _bannerAd;
    final size = _adSize;
    if (ad == null || size == null) return const SizedBox.shrink();
    return Container(
      alignment: Alignment.center,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: SizedBox(
        width: size.width.toDouble(),
        height: size.height.toDouble(),
        child: AdWidget(ad: ad),
      ),
    );
  }
}
