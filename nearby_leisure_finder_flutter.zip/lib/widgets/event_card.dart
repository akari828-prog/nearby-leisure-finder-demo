import 'package:flutter/material.dart';

import '../models/leisure_event.dart';

class EventCard extends StatelessWidget {
  const EventCard({
    required this.event,
    required this.onTap,
    super.key,
  });

  final LeisureEvent event;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final dateLabel = _dateSpan(event.startTime, event.endTime);

    return Card(
      clipBehavior: Clip.antiAlias,
      elevation: 0,
      color: theme.colorScheme.surfaceContainerLow,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: theme.colorScheme.outlineVariant),
      ),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Text(
                      event.title,
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  DecoratedBox(
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 11,
                        vertical: 7,
                      ),
                      child: Text(
                        event.formattedDistance,
                        style: theme.textTheme.labelLarge?.copyWith(
                          color: theme.colorScheme.onPrimaryContainer,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              if (dateLabel != null) ...<Widget>[
                const SizedBox(height: 12),
                _InfoLine(icon: Icons.event_outlined, text: dateLabel),
              ],
              if (event.address.trim().isNotEmpty) ...<Widget>[
                const SizedBox(height: 8),
                _InfoLine(icon: Icons.place_outlined, text: event.address),
              ],
              if (event.summary.trim().isNotEmpty) ...<Widget>[
                const SizedBox(height: 12),
                Text(
                  event.summary,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodyMedium?.copyWith(height: 1.45),
                ),
              ],
              if (event.sourceName.trim().isNotEmpty) ...<Widget>[
                const SizedBox(height: 13),
                Row(
                  children: <Widget>[
                    Icon(
                      Icons.article_outlined,
                      size: 16,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        event.sourceName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.labelMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Icon(
                      Icons.open_in_new,
                      size: 17,
                      color: theme.colorScheme.primary,
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  String? _dateSpan(DateTime? start, DateTime? end) {
    if (start == null && end == null) return null;
    if (start == null) return '${_formatDate(end!)}まで';
    if (end == null) return _formatDate(start);
    if (start.year == end.year &&
        start.month == end.month &&
        start.day == end.day) {
      return '${_formatDate(start)}〜${_formatTime(end)}';
    }
    return '${_formatDate(start)}〜${_formatDate(end)}';
  }

  String _formatDate(DateTime date) {
    final local = date.toLocal();
    const weekdays = <String>['月', '火', '水', '木', '金', '土', '日'];
    final weekday = weekdays[local.weekday - 1];
    final dateLabel = '${local.year}年${local.month}月${local.day}日($weekday)';
    if (local.hour == 0 && local.minute == 0) return dateLabel;
    return '$dateLabel ${_formatTime(local)}';
  }

  String _formatTime(DateTime date) {
    final local = date.toLocal();
    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }
}

class _InfoLine extends StatelessWidget {
  const _InfoLine({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.only(top: 2),
          child: Icon(
            icon,
            size: 17,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(width: 7),
        Expanded(
          child: Text(
            text,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ),
      ],
    );
  }
}
