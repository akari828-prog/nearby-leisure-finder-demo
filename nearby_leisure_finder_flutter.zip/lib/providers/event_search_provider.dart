import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';

import '../config/app_config.dart';
import '../models/ai_event_result.dart';
import '../models/leisure_event.dart';
import '../models/rss_event.dart';
import '../services/gemini_service.dart';
import '../services/geocoding_service.dart';
import '../services/location_service.dart';
import '../services/rss_service.dart';

enum SearchStage {
  idle,
  gettingLocation,
  fetchingRss,
  analyzingWithAI,
  geocoding,
  completed,
  error,
}

extension SearchStageLabel on SearchStage {
  String get japaneseLabel => switch (this) {
        SearchStage.idle => '「現在地から探す」を押すと検索を開始します。',
        SearchStage.gettingLocation => '現在地を取得しています…',
        SearchStage.fetchingRss => 'イベント情報を取得しています…',
        SearchStage.analyzingWithAI => 'AIがイベントを整理しています…',
        SearchStage.geocoding => '現在地からの距離を計算しています…',
        SearchStage.completed => '検索が完了しました。',
        SearchStage.error => '検索を完了できませんでした。',
      };
}

class EventSearchState {
  const EventSearchState({
    required this.stage,
    this.events = const <LeisureEvent>[],
    this.errorMessage,
    this.locationIssue,
  });

  const EventSearchState.initial() : this(stage: SearchStage.idle);

  final SearchStage stage;
  final List<LeisureEvent> events;
  final String? errorMessage;
  final LocationIssue? locationIssue;

  bool get isSearching =>
      stage == SearchStage.gettingLocation ||
      stage == SearchStage.fetchingRss ||
      stage == SearchStage.analyzingWithAI ||
      stage == SearchStage.geocoding;

  EventSearchState copyWith({
    SearchStage? stage,
    List<LeisureEvent>? events,
    String? errorMessage,
    LocationIssue? locationIssue,
    bool clearError = false,
    bool clearLocationIssue = false,
  }) {
    return EventSearchState(
      stage: stage ?? this.stage,
      events: events ?? this.events,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
      locationIssue:
          clearLocationIssue ? null : locationIssue ?? this.locationIssue,
    );
  }
}

final locationServiceProvider =
    Provider<LocationService>((ref) => LocationService());

final rssServiceProvider = Provider<RssService>((ref) {
  final service = RssService();
  ref.onDispose(service.dispose);
  return service;
});

final geocodingServiceProvider =
    Provider<GeocodingService>((ref) => GeocodingService());

final firebaseStartupErrorProvider = Provider<String?>((ref) => null);

final geminiServiceProvider = Provider<GeminiService>(
  (ref) => GeminiService(startupError: ref.watch(firebaseStartupErrorProvider)),
);

final eventSearchProvider =
    AsyncNotifierProvider<EventSearchNotifier, EventSearchState>(
  EventSearchNotifier.new,
);

class EventSearchNotifier extends AsyncNotifier<EventSearchState> {
  late final LocationService _locationService;
  late final RssService _rssService;
  late final GeocodingService _geocodingService;
  late final GeminiService _geminiService;

  @override
  EventSearchState build() {
    _locationService = ref.read(locationServiceProvider);
    _rssService = ref.read(rssServiceProvider);
    _geocodingService = ref.read(geocodingServiceProvider);
    _geminiService = ref.read(geminiServiceProvider);
    return const EventSearchState.initial();
  }

  Future<void> search() async {
    final current = state.value;
    if (current?.isSearching ?? false) return;

    _setState(
      SearchStage.gettingLocation,
      events: const <LeisureEvent>[],
      clearError: true,
      clearLocationIssue: true,
    );
    if (AppConfig.useMockData) {
      await _searchMockData();
      return;
    }
    if (_geminiService.startupError != null) {
      _setState(
        SearchStage.error,
        errorMessage:
            'Firebaseを初期化できません。Firebaseの登録情報とApp Checkの設定を確認してください。',
      );
      return;
    }

    try {
      final location = await _locationService.getCurrentLocation();
      final area = await _geocodingService.getAreaLabel(location);

      _setState(SearchStage.fetchingRss);
      final rssEvents = await _rssService.fetchLatestEvents(area: area);
      if (rssEvents.isEmpty) {
        _setState(SearchStage.completed, events: const <LeisureEvent>[]);
        return;
      }

      _setState(SearchStage.analyzingWithAI);
      final aiResults = await _geminiService.analyze(rssEvents);
      _setState(SearchStage.geocoding);
      final events = await _convertResults(
        rssEvents: rssEvents,
        aiResults: aiResults,
        userLocation: location,
      );
      _setState(SearchStage.completed, events: events);
    } on LocationServiceException catch (error) {
      _setState(
        SearchStage.error,
        errorMessage: error.message,
        locationIssue: error.issue,
      );
    } on RssFetchException catch (error) {
      _setState(SearchStage.error, errorMessage: error.message);
    } catch (_) {
      _setState(
        SearchStage.error,
        errorMessage:
            '検索中にエラーが発生しました。通信状況や設定を確認して、時間をおいて再検索してください。',
      );
    }
  }

  Future<List<LeisureEvent>> _convertResults({
    required List<RssEvent> rssEvents,
    required List<AiEventResult> aiResults,
    required DeviceLocation userLocation,
  }) async {
    final candidates = aiResults.where((result) {
      return result.isLeisure &&
          result.index >= 0 &&
          result.index < rssEvents.length &&
          result.address != null &&
          result.address!.trim().isNotEmpty &&
          !(result.endTime?.isBefore(DateTime.now()) ?? false);
    }).toList(growable: false);

    final addresses = candidates
        .map((result) => result.address!.trim())
        .toList(growable: false);
    final coordinatesByAddress =
        await _geocodingService.geocodeSequentially(addresses);

    final events = <LeisureEvent>[];
    for (final result in candidates) {
      final address = result.address!.trim();
      final coordinates = coordinatesByAddress[address.toLowerCase()];
      if (coordinates == null) continue;

      final distanceMeters = Geolocator.distanceBetween(
        userLocation.latitude,
        userLocation.longitude,
        coordinates.latitude,
        coordinates.longitude,
      );
      final distanceKm = distanceMeters / 1000;
      if (distanceKm > AppConfig.searchRadiusKm) continue;

      final original = rssEvents[result.index];
      events.add(
        LeisureEvent(
          title: original.title,
          summary: result.summary,
          url: original.url,
          address: address,
          distanceKm: distanceKm,
          startTime: result.startTime,
          endTime: result.endTime,
          sourceName: original.sourceName,
          latitude: coordinates.latitude,
          longitude: coordinates.longitude,
        ),
      );
    }
    events.sort((a, b) => a.distanceKm.compareTo(b.distanceKm));
    return List<LeisureEvent>.unmodifiable(events);
  }

  Future<void> _searchMockData() async {
    await Future<void>.delayed(const Duration(milliseconds: 120));
    _setState(SearchStage.fetchingRss);
    await Future<void>.delayed(const Duration(milliseconds: 120));
    _setState(SearchStage.analyzingWithAI);
    await Future<void>.delayed(const Duration(milliseconds: 120));
    _setState(SearchStage.geocoding);

    const userLocation = DeviceLocation(latitude: 35.6812, longitude: 139.7671);
    final now = DateTime.now();
    final sampleEvents = <LeisureEvent>[
      LeisureEvent(
        title: 'サンプル：東京駅前マルシェ',
        summary: '地元の食品や雑貨を販売するマルシェの表示テストです。',
        url: 'https://example.com/events/tokyo-marche',
        address: '東京都千代田区丸の内1丁目',
        distanceKm: 0,
        startTime: now.add(const Duration(days: 2, hours: 1)),
        endTime: now.add(const Duration(days: 2, hours: 6)),
        sourceName: 'サンプルデータ',
        latitude: 35.6812,
        longitude: 139.7671,
      ),
      LeisureEvent(
        title: 'サンプル：上野公園の季節イベント',
        summary: '公園内の展示や屋外企画を紹介するサンプルイベントです。',
        url: 'https://example.com/events/ueno',
        address: '東京都台東区上野公園',
        distanceKm: 0,
        startTime: now.add(const Duration(days: 3, hours: 2)),
        endTime: now.add(const Duration(days: 3, hours: 7)),
        sourceName: 'サンプルデータ',
        latitude: 35.7156,
        longitude: 139.7745,
      ),
      LeisureEvent(
        title: 'サンプル：浅草の地域イベント',
        summary: '家族で楽しめる地域の催しを表示するサンプルです。',
        url: 'https://example.com/events/asakusa',
        address: '東京都台東区浅草',
        distanceKm: 0,
        startTime: now.add(const Duration(days: 5, hours: 3)),
        endTime: now.add(const Duration(days: 5, hours: 8)),
        sourceName: 'サンプルデータ',
        latitude: 35.7148,
        longitude: 139.7967,
      ),
      LeisureEvent(
        title: 'サンプル：横浜のイベント（範囲外）',
        summary: '10kmの距離フィルターが働くことを確認するためのサンプルです。',
        url: 'https://example.com/events/yokohama',
        address: '神奈川県横浜市中区',
        distanceKm: 0,
        startTime: now.add(const Duration(days: 4, hours: 1)),
        endTime: now.add(const Duration(days: 4, hours: 6)),
        sourceName: 'サンプルデータ',
        latitude: 35.4437,
        longitude: 139.6380,
      ),
    ];

    final events = sampleEvents
        .map((event) {
          final distanceMeters = Geolocator.distanceBetween(
            userLocation.latitude,
            userLocation.longitude,
            event.latitude!,
            event.longitude!,
          );
          return event.copyWith(distanceKm: distanceMeters / 1000);
        })
        .where((event) => event.distanceKm <= AppConfig.searchRadiusKm)
        .toList()
      ..sort((a, b) => a.distanceKm.compareTo(b.distanceKm));

    _setState(
      SearchStage.completed,
      events: List<LeisureEvent>.unmodifiable(events),
    );
  }

  void _setState(
    SearchStage stage, {
    List<LeisureEvent>? events,
    String? errorMessage,
    LocationIssue? locationIssue,
    bool clearError = false,
    bool clearLocationIssue = false,
  }) {
    final current = state.value ?? const EventSearchState.initial();
    state = AsyncData(
      current.copyWith(
        stage: stage,
        events: events,
        errorMessage: errorMessage,
        locationIssue: locationIssue,
        clearError: clearError,
        clearLocationIssue: clearLocationIssue,
      ),
    );
  }
}
