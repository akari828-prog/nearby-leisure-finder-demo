import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/app_config.dart';
import '../providers/ad_provider.dart';
import '../providers/event_search_provider.dart';
import '../services/browser_service.dart';
import '../services/location_service.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/event_card.dart';
import '../widgets/search_status.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncSearch = ref.watch(eventSearchProvider);
    final searchState = asyncSearch.value ?? const EventSearchState.initial();
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Expanded(
              child: CustomScrollView(
                slivers: <Widget>[
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
                    sliver: SliverToBoxAdapter(
                      child: _Header(
                        isMockMode: AppConfig.useMockData,
                        isSearching: searchState.isSearching,
                        onSearch: () =>
                            ref.read(eventSearchProvider.notifier).search(),
                      ),
                    ),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    sliver: SliverToBoxAdapter(
                      child: SearchStatus(searchState: searchState),
                    ),
                  ),
                  if (searchState.locationIssue case final issue?)
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
                      sliver: SliverToBoxAdapter(
                        child: _LocationSettingsButton(issue: issue),
                      ),
                    ),
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
                    sliver: SliverToBoxAdapter(
                      child: _ResultsHeading(
                        count: searchState.events.length,
                        isCompleted: searchState.stage == SearchStage.completed,
                      ),
                    ),
                  ),
                  if (searchState.stage == SearchStage.completed &&
                      searchState.events.isEmpty)
                    const SliverPadding(
                      padding: EdgeInsets.fromLTRB(20, 0, 20, 24),
                      sliver: SliverToBoxAdapter(child: _EmptyResults()),
                    )
                  else if (searchState.events.isNotEmpty)
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                      sliver: SliverList.separated(
                        itemCount: searchState.events.length,
                        itemBuilder: (context, index) => EventCard(
                          event: searchState.events[index],
                          onTap: () => _openEvent(
                            context,
                            ref,
                            searchState.events[index].url,
                          ),
                        ),
                        separatorBuilder: (context, index) =>
                            const SizedBox(height: 10),
                      ),
                    )
                  else if (searchState.stage == SearchStage.idle)
                    const SliverPadding(
                      padding: EdgeInsets.fromLTRB(20, 0, 20, 24),
                      sliver: SliverToBoxAdapter(child: _InitialHint()),
                    ),
                ],
              ),
            ),
            const BannerAdWidget(),
          ],
        ),
      ),
    );
  }

  Future<void> _openEvent(
    BuildContext context,
    WidgetRef ref,
    String url,
  ) async {
    final browser = BrowserService();
    if (browser.safeHttpUri(url) == null) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('記事のURLが無効です。')),
      );
      return;
    }
    final opened = await ref.read(adServiceProvider).handleEventTap(
          eventUrl: url,
          openEvent: () => browser.openUrl(url),
        );
    if (!context.mounted || opened == null || opened) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('記事を開けませんでした。URLを確認してください。')),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({
    required this.isMockMode,
    required this.isSearching,
    required this.onSearch,
  });

  final bool isMockMode;
  final bool isSearching;
  final VoidCallback onSearch;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(
                Icons.explore_outlined,
                color: theme.colorScheme.onPrimaryContainer,
                size: 27,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                '近くで、ちょっと遊ぼう。',
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.5,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          '今いる場所から10km以内のイベントやおでかけ先を探します。',
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
            height: 1.45,
          ),
        ),
        if (isMockMode) ...<Widget>[
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
            decoration: BoxDecoration(
              color: theme.colorScheme.tertiaryContainer,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              'デモ表示中：サンプルイベントは実在の開催情報ではありません。',
              style: theme.textTheme.labelMedium?.copyWith(
                color: theme.colorScheme.onTertiaryContainer,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
        const SizedBox(height: 15),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            onPressed: isSearching ? null : onSearch,
            icon: const Icon(Icons.my_location),
            label: const Text('現在地から探す'),
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(52),
              textStyle: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w700,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
        ),
        const SizedBox(height: 9),
        Text(
          '位置情報は検索時だけ取得します。GPS座標は端末内で距離計算に使い、地域名だけをRSS検索に利用します。',
          style: theme.textTheme.labelSmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

class _ResultsHeading extends StatelessWidget {
  const _ResultsHeading({required this.count, required this.isCompleted});

  final int count;
  final bool isCompleted;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: <Widget>[
        Text(
          isCompleted ? '見つかったイベント' : 'イベント',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
        if (isCompleted) ...<Widget>[
          const SizedBox(width: 8),
          Text(
            '$count件',
            style: theme.textTheme.labelLarge?.copyWith(
              color: theme.colorScheme.primary,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ],
    );
  }
}

class _EmptyResults extends StatelessWidget {
  const _EmptyResults();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(Icons.event_busy_outlined, color: theme.colorScheme.primary),
          const SizedBox(height: 10),
          Text(
            '現在地から10km以内に見つかりませんでした。',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '掲載元の更新後に情報が見つかることがあります。時間をおいて再検索してください。',
            style: theme.textTheme.bodySmall?.copyWith(height: 1.45),
          ),
        ],
      ),
    );
  }
}

class _InitialHint extends StatelessWidget {
  const _InitialHint();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Row(
        children: <Widget>[
          Icon(Icons.lightbulb_outline, color: theme.colorScheme.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'ボタンを押すと、検索のためだけに現在地を取得します。',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LocationSettingsButton extends ConsumerWidget {
  const _LocationSettingsButton({required this.issue});

  final LocationIssue issue;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final shouldOpenAppSettings =
        issue == LocationIssue.permissionDeniedForever;
    if (!shouldOpenAppSettings && issue != LocationIssue.serviceDisabled) {
      return const SizedBox.shrink();
    }

    return Align(
      alignment: Alignment.centerLeft,
      child: TextButton.icon(
        onPressed: () async {
          try {
            if (shouldOpenAppSettings) {
              await ref.read(locationServiceProvider).openAppSettings();
            } else {
              await ref.read(locationServiceProvider).openLocationSettings();
            }
          } catch (_) {
            if (!context.mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('設定画面を開けませんでした。端末の設定から変更してください。'),
              ),
            );
          }
        },
        icon: const Icon(Icons.settings_outlined),
        label: Text(
          shouldOpenAppSettings ? 'アプリの位置情報設定を開く' : '端末の位置情報設定を開く',
        ),
      ),
    );
  }
}
