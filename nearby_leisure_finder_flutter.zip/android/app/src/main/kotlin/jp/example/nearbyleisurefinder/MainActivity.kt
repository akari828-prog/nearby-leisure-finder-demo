package jp.example.nearbyleisurefinder

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
